# Attribute属性值

    var screenHeight = api.sreenHeight;
    var winName = api.winName;
    var winWidth = api.winWidth;
    var winHeight = api.winHeight;
    var frameName = api.frameName || '';
    var frameWidth = api.frameWidth || '';
    var frameHeight = api.frameHeight || '';
    var pageParam = api.pageParam; //比如： {"name" : "tans-con"}
    var wghParam = api.wgtParam;

# Constant常量

# Event事件

scrolltobottom 
    
    Window 或者 Frame 页面滑动到底部事件，字符串类型
    可用于实现滚动到底部，加载更多功能
    
    api.addEventListener({
        name: "scrolltobottom",
        extra: {
            threshold:0     设置距离低端错少触发
        }
    },function(ret, err) {
        alert("以及到底端了，加载更多");
    });

shake

    摇动事件
    api.addEventListener({
        name: "shake",
    },function(ret, err) {
        alert("出发了摇一摇事件");
    });

takescreenshot

    截屏事件
    api.addEventListener({
        name: "takescreenshot"
    },function(ret,err){
        alert("你触发了截屏事件");
    });

swipedown
    向下轻扫事件
swipLift
    向左轻扫
swipright
    向右轻扫
swiptop
    向上轻扫

tap
    单击事件
longpress
    单击事件

viewappear
    window显示到屏幕事件
viewdisappear
    window离开屏幕事件

noticeclicked
    状态栏被用户点击

appintent
    本应用被其他应用调起来

launchviewclicked
    启动页被用户点击

# Method 方法

openWin/closeWin/closeToWin/setWinAttr

openFrame/closeFrame/setFrameAttr/bringFrameToFront
